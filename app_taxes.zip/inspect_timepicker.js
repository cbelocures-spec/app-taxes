const puppeteer = require('puppeteer');
const db = require('./database');

async function inspectTimepicker() {
  const settings = db.getSettings();
  console.log("Using credentials:", settings.username);
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // Login
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Inicio') || document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if (type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) {
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }

    // Go to OT list and click NUEVO
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2' });
    await new Promise(res => setTimeout(res, 3000));
    
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const nuevo = buttons.find(b => b.textContent.trim().toUpperCase().includes('NUEVO'));
      if (nuevo) nuevo.click();
    });
    await new Promise(res => setTimeout(res, 3000));

    // Inspect the Horario form-group HTML
    const horarioGroupHTML = await page.evaluate(() => {
      const groups = Array.from(document.querySelectorAll('.form-group, .taxes-form-group'));
      const group = groups.find(g => g.textContent.includes('Horario'));
      return group ? group.outerHTML : 'NOT FOUND';
    });

    console.log("=== HORARIO GROUP HTML ===");
    console.log(horarioGroupHTML);

  } catch (error) {
    console.error("Error inspecting timepicker:", error);
  } finally {
    await browser.close();
  }
}

inspectTimepicker();
