const puppeteer = require('puppeteer');
const db = require('./database');

async function inspectTaskSelects() {
  const settings = db.getSettings();
  console.log("=== INSPECT TASK SELECTS (Centro Costo + Empleado) ===");
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // Login
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Inicio') || document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if (type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) {
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }
    console.log("Login OK");

    // Go to OT list and click NUEVO
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2' });
    await new Promise(res => setTimeout(res, 3000));
    
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const nuevo = buttons.find(b => b.textContent.trim().toUpperCase().includes('NUEVO'));
      if (nuevo) nuevo.click();
    });
    await new Promise(res => setTimeout(res, 3000));
    console.log("Form opened");

    // Click AGREGAR TAREA
    console.log("\nClicking AGREGAR TAREA...");
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const addBtn = buttons.find(b => b.textContent.includes('AGREGAR TAREA') || b.textContent.includes('Agregar Tarea'));
      if (addBtn) addBtn.click();
    });
    await new Promise(res => setTimeout(res, 2000));

    // Get ALL selects on the page with their names, IDs, and options
    console.log("\n=== ALL SELECT ELEMENTS ON PAGE ===");
    const allSelects = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('select')).map(s => ({
        id: s.id,
        name: s.name,
        className: s.className,
        optionCount: s.options.length,
        options: Array.from(s.options).map(o => ({ value: o.value, text: o.textContent.trim() })),
        parentClass: s.parentElement ? s.parentElement.className : '',
        grandParentClass: s.parentElement && s.parentElement.parentElement ? s.parentElement.parentElement.className : '',
        nearbyLabel: (() => {
          // Walk up the tree to find a nearby label
          let el = s.parentElement;
          for (let i = 0; i < 5; i++) {
            if (!el) break;
            const labels = el.querySelectorAll('label');
            if (labels.length > 0) return labels[0].textContent.trim();
            el = el.parentElement;
          }
          return '';
        })()
      }));
    });

    allSelects.forEach((s, i) => {
      console.log(`\nSelect #${i}:`);
      console.log(`  ID: "${s.id}"`);
      console.log(`  Name: "${s.name}"`);
      console.log(`  Class: "${s.className}"`);
      console.log(`  Parent class: "${s.parentClass}"`);
      console.log(`  Grand-parent class: "${s.grandParentClass}"`);
      console.log(`  Nearby label: "${s.nearbyLabel}"`);
      console.log(`  Options (${s.optionCount}):`);
      s.options.forEach(o => console.log(`    value="${o.value}" text="${o.text}"`));
    });

    // Now select a Centro de Costo and wait for employee AJAX
    console.log("\n\n=== SELECTING FIRST CENTRO DE COSTO AND WAITING FOR EMPLOYEE AJAX ===");
    
    // Find the centro costo select in the task card
    const ccSelectInfo = await page.evaluate(() => {
      const selects = Array.from(document.querySelectorAll('select'));
      const ccSelect = selects.find(s => {
        const name = (s.name || '').toLowerCase();
        return name.includes('centro') || name.includes('costo');
      });
      if (ccSelect && ccSelect.options.length > 1) {
        // Select the first non-empty option
        const firstOption = Array.from(ccSelect.options).find(o => o.value && o.value !== '');
        if (firstOption) {
          ccSelect.value = firstOption.value;
          ccSelect.dispatchEvent(new Event('change', { bubbles: true }));
          return { selected: true, value: firstOption.value, text: firstOption.text, selectName: ccSelect.name };
        }
      }
      return { selected: false };
    });
    
    console.log("Centro Costo selection:", JSON.stringify(ccSelectInfo));
    
    // Wait for AJAX to populate employee
    console.log("Waiting 5 seconds for AJAX...");
    await new Promise(res => setTimeout(res, 5000));

    // Now check employee select
    console.log("\n=== EMPLOYEE SELECT AFTER AJAX ===");
    const empSelectInfo = await page.evaluate(() => {
      const selects = Array.from(document.querySelectorAll('select'));
      const empSelect = selects.find(s => {
        const name = (s.name || '').toLowerCase();
        return name.includes('empleado');
      });
      if (empSelect) {
        return {
          name: empSelect.name,
          id: empSelect.id,
          optionCount: empSelect.options.length,
          options: Array.from(empSelect.options).map(o => ({ value: o.value, text: o.textContent.trim() }))
        };
      }
      return { found: false };
    });
    
    console.log("Employee select:", JSON.stringify(empSelectInfo, null, 2));

    // Also get all inputs (including hidden) related to tasks
    console.log("\n=== TASK-RELATED HIDDEN INPUTS ===");
    const taskInputs = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('input, textarea, select')).filter(el => {
        const name = (el.name || '').toLowerCase();
        return name.includes('tarea') || name.includes('centro') || name.includes('empleado') || 
               name.includes('hora') || name.includes('actividad');
      }).map(el => ({
        tag: el.tagName,
        type: el.type,
        name: el.name,
        id: el.id,
        value: el.value,
        className: el.className
      }));
    });
    taskInputs.forEach(i => console.log("  ", JSON.stringify(i)));

  } catch (error) {
    console.error("Error:", error);
  } finally {
    await browser.close();
  }
}

inspectTaskSelects();
