const puppeteer = require('puppeteer');
const db = require('./database');

async function inspectTaskDetail() {
  const settings = db.getSettings();
  console.log("=== INSPECT TASK DETAIL ===");
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // Login
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Inicio') || document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if (type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) {
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }
    console.log("Login OK");

    // Go to OT list and click NUEVO
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2' });
    await new Promise(res => setTimeout(res, 3000));
    
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const nuevo = buttons.find(b => b.textContent.trim().toUpperCase().includes('NUEVO'));
      if (nuevo) nuevo.click();
    });
    await new Promise(res => setTimeout(res, 3000));
    console.log("Form opened");

    // Click AGREGAR TAREA
    console.log("Clicking AGREGAR TAREA...");
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const addBtn = buttons.find(b => b.textContent.includes('AGREGAR TAREA') || b.textContent.includes('Agregar Tarea'));
      if (addBtn) addBtn.click();
    });
    await new Promise(res => setTimeout(res, 2000));

    // Select Centro de Costo = MECANICA (value is "15")
    console.log("Selecting MECANICA Centro de Costo (value='15')...");
    await page.evaluate(() => {
      const ccSelect = document.getElementById('centro_costo_0') || document.querySelector('select[name="syj_centro_costo_id_0"]');
      if (ccSelect) {
        ccSelect.value = "15"; // MECANICA is value 15
        ccSelect.dispatchEvent(new Event('change', { bubbles: true }));
      } else {
        console.log("Could not find Centro de Costo select!");
      }
    });

    console.log("Waiting 4 seconds for AJAX/Vue update...");
    await new Promise(res => setTimeout(res, 4000));

    // Analyze all form elements on the page
    console.log("Analyzing all form elements on the page...");
    const pageElements = await page.evaluate(() => {
      const inputs = Array.from(document.querySelectorAll('input, select, textarea'));
      return inputs.map((el, idx) => {
        // Find ancestor hierarchy
        const hierarchy = [];
        let p = el.parentElement;
        while (p && hierarchy.length < 4) {
          hierarchy.push(`${p.tagName}.${p.className.split(' ').join('.')}`);
          p = p.parentElement;
        }
        return {
          idx,
          tag: el.tagName,
          id: el.id,
          name: el.name || el.getAttribute('name') || '',
          type: el.type || '',
          placeholder: el.getAttribute('placeholder') || '',
          className: el.className,
          value: el.value,
          hierarchy: hierarchy.join(' -> ')
        };
      });
    });

    console.log("\n=== ALL FORM ELEMENTS ON PAGE ===");
    pageElements.forEach(el => {
      console.log(`[${el.idx}] ${el.tag} id="${el.id}" name="${el.name}" type="${el.type}" class="${el.className}" placeholder="${el.placeholder}" value="${el.value}"`);
      console.log(`      Path: ${el.hierarchy}`);
    });

  } catch (error) {
    console.error("Error:", error);
  } finally {
    await browser.close();
  }
}

inspectTaskDetail();
