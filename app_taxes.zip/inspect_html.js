const puppeteer = require('puppeteer');
const db = require('./database');

async function inspectHTML() {
  const settings = db.getSettings();
  console.log("Using credentials:", settings.username);
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // Login
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Inicio') || document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if (type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) {
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }

    // Go to OT list and click NUEVO
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2' });
    await new Promise(res => setTimeout(res, 3000));
    
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const nuevo = buttons.find(b => b.textContent.trim().toUpperCase().includes('NUEVO'));
      if (nuevo) nuevo.click();
    });
    await new Promise(res => setTimeout(res, 3000));

    // Find Rodado searchable input and click it
    const wrapperHTML = await page.evaluate(() => {
      const groups = Array.from(document.querySelectorAll('.form-group, .taxes-form-group'));
      const rodadoGroup = groups.find(g => g.textContent.toLowerCase().includes('rodado'));
      if (rodadoGroup) {
        const input = rodadoGroup.querySelector('.searchable-input, input[type="text"]');
        if (input) {
          input.click();
        }
        return rodadoGroup.outerHTML;
      }
      return 'NOT FOUND';
    });

    console.log("=== WRAPPER HTML BEFORE TYPING ===");
    console.log(wrapperHTML);

    // Type FORD and log HTML again to see the dropdown list items
    const inputSelector = await page.evaluate(() => {
      const groups = Array.from(document.querySelectorAll('.form-group, .taxes-form-group'));
      const rodadoGroup = groups.find(g => g.textContent.toLowerCase().includes('rodado'));
      if (rodadoGroup) {
        const input = rodadoGroup.querySelector('.searchable-input, input[type="text"]');
        if (input) {
          input.setAttribute('id', 'test_rodado_input2');
          return '#test_rodado_input2';
        }
      }
      return null;
    });

    if (inputSelector) {
      await page.type(inputSelector, "FORD", { delay: 100 });
      await new Promise(res => setTimeout(res, 3000));

      const wrapperHTMLAfter = await page.evaluate(() => {
        const group = document.getElementById('test_rodado_input2').closest('.form-group, .taxes-form-group');
        return group ? group.outerHTML : 'GROUP NOT FOUND';
      });

      console.log("=== WRAPPER HTML AFTER TYPING 'FORD' ===");
      console.log(wrapperHTMLAfter);
    }

  } catch (error) {
    console.error("Error inspecting HTML:", error);
  } finally {
    await browser.close();
  }
}

inspectHTML();
