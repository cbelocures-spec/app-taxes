/**
 * verify_ot.js - Verification script to check if work orders exist on Taxes.com.ar
 * This navigates to the OT list page and searches for recently created orders.
 * Also takes a screenshot for debugging purposes.
 */
const puppeteer = require('puppeteer');
const db = require('./database');
const path = require('path');

async function verifyOrders() {
  const settings = db.getSettings();
  console.log("=== Verificando Órdenes en Taxes.com.ar ===");
  console.log("Usuario:", settings.username);
  console.log("URL:", settings.portalUrl);

  let browser = null;
  try {
    browser = await puppeteer.launch({
      headless: false, // Show browser for debugging
      executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 800 });

    // 1. Login
    console.log("\n1. Iniciando sesión...");
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });
    
    // Check if already logged in
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('BELOCURES') || 
             document.body.textContent.includes('Inicio') || 
             document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      console.log("Ingresando credenciales...");
      const inputs = await page.$$('input');
      let userFilled = false, passFilled = false;
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if ((type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) && !userFilled) {
          await input.focus();
          await input.type(settings.username);
          userFilled = true;
        } else if ((type === 'password' || name.includes('pass')) && !passFilled) {
          await input.focus();
          await input.type(settings.password);
          passFilled = true;
        }
      }
      // Click login
      await page.evaluate(() => {
        const btns = Array.from(document.querySelectorAll('button'));
        const loginBtn = btns.find(b => b.textContent.toLowerCase().includes('iniciar') || b.textContent.toLowerCase().includes('ingresar'));
        if (loginBtn) loginBtn.click();
        else {
          const submit = document.querySelector('button[type="submit"]');
          if (submit) submit.click();
        }
      });
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
      await new Promise(r => setTimeout(r, 3000));
    }
    console.log("✓ Login exitoso");

    // 2. Navigate to OT list
    console.log("\n2. Navegando a lista de Órdenes de Trabajo...");
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2', timeout: 30000 });
    await new Promise(r => setTimeout(r, 3000));

    // Take screenshot of OT list
    const screenshotPath = path.join(__dirname, 'verify_ot_list.png');
    await page.screenshot({ path: screenshotPath, fullPage: false });
    console.log(`✓ Screenshot guardado en: ${screenshotPath}`);

    // 3. Extract OT list from the page
    console.log("\n3. Extrayendo lista de OTs desde la página...");
    const pageOTs = await page.evaluate(() => {
      const rows = Array.from(document.querySelectorAll('tr, .table-row, .list-item'));
      const results = [];
      rows.forEach(row => {
        const text = row.textContent.trim();
        if (text.length > 10) {
          results.push(text.substring(0, 200));
        }
      });
      return results;
    });

    console.log(`\nEncontradas ${pageOTs.length} filas en la tabla de OTs:`);
    pageOTs.forEach((ot, i) => {
      console.log(`  [${i}] ${ot.replace(/\s+/g, ' ').substring(0, 150)}`);
    });

    // 4. Also get the full HTML of the page body for debugging
    console.log("\n4. Analizando contenido de la página...");
    const bodyText = await page.evaluate(() => document.body.innerText);
    
    // Search for our order internos
    const orders = db.getWorkOrders();
    console.log(`\n5. Buscando ${orders.length} órdenes locales en la web de Taxes:`);
    
    for (const order of orders) {
      const found = bodyText.includes(order.interno);
      console.log(`  ${found ? '✓' : '✗'} OT Interno: "${order.interno}" - Rodado: "${order.rodado}" - Sync: ${order.syncStatus} ${found ? '(ENCONTRADA en Taxes)' : '(NO ENCONTRADA en Taxes)'}`);
    }

    // 5. Try clicking "NUEVO" and take a screenshot of the form
    console.log("\n6. Abriendo formulario de creación para inspeccionar campos...");
    const nuevoClicked = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button, a'));
      for (const btn of buttons) {
        const text = btn.textContent.trim().toUpperCase();
        if (text === 'NUEVO' || text === 'NUEVA') {
          btn.click();
          return true;
        }
      }
      return false;
    });
    
    if (nuevoClicked) {
      await new Promise(r => setTimeout(r, 3000));
      
      const formScreenshot = path.join(__dirname, 'verify_ot_form.png');
      await page.screenshot({ path: formScreenshot, fullPage: false });
      console.log(`✓ Screenshot del formulario guardado en: ${formScreenshot}`);
      
      // Inspect the form structure
      const formInfo = await page.evaluate(() => {
        const info = {};
        
        // Find all form groups
        const groups = Array.from(document.querySelectorAll('.form-group, .taxes-form-group, [class*="form"]'));
        info.formGroups = groups.map(g => {
          const label = g.querySelector('label');
          const inputs = Array.from(g.querySelectorAll('input, select, textarea'));
          return {
            label: label ? label.textContent.trim() : '(no label)',
            inputs: inputs.map(inp => ({
              tag: inp.tagName,
              type: inp.type || '',
              name: inp.name || '',
              id: inp.id || '',
              className: inp.className.substring(0, 80),
              value: inp.value || ''
            }))
          };
        }).filter(g => g.inputs.length > 0);
        
        // Find all visible buttons
        info.buttons = Array.from(document.querySelectorAll('button')).map(b => ({
          text: b.textContent.trim().substring(0, 50),
          className: b.className.substring(0, 80),
          type: b.type || ''
        })).filter(b => b.text.length > 0);
        
        // Check for searchable selects
        info.searchableSelects = Array.from(document.querySelectorAll('[class*="searchable"], [class*="vs__"], [class*="select2"]')).map(el => ({
          className: el.className.substring(0, 100),
          id: el.id || '',
          textContent: el.textContent.trim().substring(0, 100)
        }));

        // Check for the "Guardar" button specifically
        const guardarBtns = Array.from(document.querySelectorAll('button')).filter(b => 
          b.textContent.toLowerCase().includes('guardar') || 
          b.textContent.toLowerCase().includes('crear') ||
          b.textContent.toLowerCase().includes('aceptar')
        );
        info.guardarButtons = guardarBtns.map(b => ({
          text: b.textContent.trim(),
          type: b.type,
          disabled: b.disabled,
          className: b.className.substring(0, 80)
        }));
        
        return info;
      });
      
      console.log("\n=== Estructura del formulario de creación ===");
      console.log(`\nCampos encontrados (${formInfo.formGroups.length}):`);
      formInfo.formGroups.forEach((g, i) => {
        console.log(`  [${i}] Label: "${g.label}"`);
        g.inputs.forEach(inp => {
          console.log(`       -> ${inp.tag} type="${inp.type}" name="${inp.name}" id="${inp.id}" class="${inp.className}" value="${inp.value}"`);
        });
      });
      
      console.log(`\nBotones Guardar/Crear (${formInfo.guardarButtons.length}):`);
      formInfo.guardarButtons.forEach(b => {
        console.log(`  "${b.text}" type="${b.type}" disabled=${b.disabled} class="${b.className}"`);
      });
      
      console.log(`\nSearchable selects (${formInfo.searchableSelects.length}):`);
      formInfo.searchableSelects.forEach(s => {
        console.log(`  class="${s.className}" id="${s.id}" text="${s.textContent}"`);
      });
      
      console.log(`\nTodos los botones (${formInfo.buttons.length}):`);
      formInfo.buttons.forEach(b => {
        console.log(`  "${b.text}" type="${b.type}" class="${b.className}"`);
      });
    } else {
      console.log("⚠ No se encontró el botón NUEVO");
    }

    // Keep browser open for 15 seconds for manual inspection
    console.log("\n=== Navegador abierto por 15 segundos para inspección manual ===");
    await new Promise(r => setTimeout(r, 15000));
    
    await browser.close();
    console.log("\n✓ Verificación completada.");

  } catch (error) {
    console.error("Error en verificación:", error);
    if (browser) await browser.close();
  }
}

verifyOrders();
