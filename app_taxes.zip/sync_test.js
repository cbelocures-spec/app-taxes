/**
 * sync_test.js - Test script that actually fills and submits a real OT on Taxes
 * Uses the correct field names and hidden inputs discovered from form inspection.
 * Runs with headless: false so user can watch the process.
 */
const puppeteer = require('puppeteer');
const db = require('./database');

const delay = ms => new Promise(res => setTimeout(res, ms));

async function testCreateOT() {
  const settings = db.getSettings();
  console.log("=== TEST: Crear OT en Taxes.com.ar ===");
  console.log("Usuario:", settings.username);

  let browser = null;
  try {
    browser = await puppeteer.launch({
      headless: false,
      executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 900 });

    // 1. LOGIN
    console.log("\n1. Iniciando sesión...");
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });
    
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Belocures') || 
             document.body.textContent.includes('Inicio') || 
             document.querySelector('.profile-user') !== null ||
             document.body.textContent.includes('paniol');
    });

    if (!isLoggedIn) {
      console.log("Ingresando credenciales...");
      const inputs = await page.$$('input');
      let userFilled = false, passFilled = false;
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if ((type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) && !userFilled) {
          await input.focus();
          await input.type(settings.username);
          userFilled = true;
        } else if ((type === 'password' || name.includes('pass')) && !passFilled) {
          await input.focus();
          await input.type(settings.password);
          passFilled = true;
        }
      }
      await page.evaluate(() => {
        const btns = Array.from(document.querySelectorAll('button'));
        const loginBtn = btns.find(b => b.textContent.toLowerCase().includes('iniciar') || b.textContent.toLowerCase().includes('ingresar'));
        if (loginBtn) loginBtn.click();
        else {
          const submit = document.querySelector('button[type="submit"]');
          if (submit) submit.click();
        }
      });
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
      await delay(3000);
    }
    console.log("✓ Login exitoso");

    // 2. NAVIGATE TO OT LIST
    console.log("\n2. Navegando a lista de OTs...");
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2', timeout: 30000 });
    await delay(3000);

    // 3. CLICK "NUEVO"
    console.log("\n3. Haciendo clic en NUEVO...");
    const nuevoClicked = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button, a'));
      for (const btn of buttons) {
        const text = btn.textContent.trim().toUpperCase();
        if (text.includes('NUEVO')) {
          btn.click();
          return true;
        }
      }
      return false;
    });
    if (!nuevoClicked) throw new Error("No se encontró botón NUEVO");
    await delay(3000);
    console.log("✓ Formulario abierto");

    // 4. FILL RODADO (Searchable Select)
    console.log("\n4. Llenando campo Rodado...");
    // The Rodado field is a searchable-select with hidden input name="rodado_id"
    // We need to: click the searchable-input, type, wait for dropdown, click option
    const rodadoFilled = await fillSearchableSelectField(page, 'Rodado', 'FORD', 'rodado_id');
    console.log(`   Rodado filled: ${rodadoFilled}`);

    // 5. FILL RESPONSABLE (Searchable Select)
    console.log("\n5. Llenando campo Responsable...");
    const respFilled = await fillSearchableSelectField(page, 'Responsable', 'BELOCURES', 'syj_empleado_id');
    console.log(`   Responsable filled: ${respFilled}`);

    // 6. FILL DATE
    console.log("\n6. Llenando fecha...");
    const today = new Date();
    const dateStr = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
    // Set the visible date input AND the hidden fecha input
    await page.evaluate((dateVal) => {
      // Set the visible date input
      const dateInput = document.querySelector('input[type="date"].taxes-datepicker');
      if (dateInput) {
        // For date inputs, we need to set the valueAsDate or use the native setter
        const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(dateInput, dateVal);
        dateInput.dispatchEvent(new Event('input', { bubbles: true }));
        dateInput.dispatchEvent(new Event('change', { bubbles: true }));
      }
      // Also set the hidden fecha input
      const hiddenFecha = document.querySelector('input[name="fecha"]');
      if (hiddenFecha) {
        hiddenFecha.value = dateVal;
        hiddenFecha.dispatchEvent(new Event('input', { bubbles: true }));
        hiddenFecha.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }, dateStr);
    console.log(`   Fecha: ${dateStr}`);

    // 7. FILL HORARIO (Timepicker)
    console.log("\n7. Llenando horario...");
    const timeStr = `${String(today.getHours()).padStart(2,'0')}:${String(today.getMinutes()).padStart(2,'0')}`;
    // The timepicker is a Bootstrap-Vue b-form-timepicker. Try setting via Vue component
    await page.evaluate((time) => {
      // Try finding the time input directly
      const timeInputs = document.querySelectorAll('input[type="time"]');
      timeInputs.forEach(ti => {
        ti.value = time;
        ti.dispatchEvent(new Event('input', { bubbles: true }));
        ti.dispatchEvent(new Event('change', { bubbles: true }));
      });
      // Also try the b-form-timepicker hidden input
      const hiddenTimeInputs = document.querySelectorAll('input[type="hidden"]');
      hiddenTimeInputs.forEach(hi => {
        if (hi.id && hi.id.includes('timepicker')) {
          hi.value = time;
          hi.dispatchEvent(new Event('input', { bubbles: true }));
        }
      });
    }, timeStr);
    console.log(`   Horario: ${timeStr}`);

    // 8. FILL TITULO (Interno de la Unidad)
    console.log("\n8. Llenando Interno de la Unidad...");
    const titulo = "TEST-APP-" + Date.now();
    await page.evaluate((val) => {
      const input = document.querySelector('input[name="titulo"]');
      if (input) {
        input.focus();
        const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(input, val);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }, titulo);
    console.log(`   Titulo: ${titulo}`);

    // 9. FILL CLASIFICACION
    console.log("\n9. Llenando Clasificación...");
    await page.evaluate((clasificacion) => {
      const select = document.querySelector('select[name="inv_ot_clasificacion_id"]');
      if (select) {
        // Find the option that matches
        const option = Array.from(select.options).find(o => 
          o.text.toLowerCase().includes(clasificacion.toLowerCase())
        );
        if (option) {
          select.value = option.value;
          select.dispatchEvent(new Event('change', { bubbles: true }));
          console.log('Selected clasificacion:', option.text, option.value);
        }
      }
    }, 'Preventivo');
    console.log("   Clasificación: Preventivo");

    // 10. FILL DESCRIPCION
    console.log("\n10. Llenando Descripción...");
    await page.evaluate((desc) => {
      const textarea = document.querySelector('textarea[name="descripcion"]');
      if (textarea) {
        textarea.focus();
        const nativeSetter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
        nativeSetter.call(textarea, desc);
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }, 'Test desde app móvil - ' + new Date().toLocaleString());
    console.log("   Descripción llenada");

    // Take screenshot before saving
    await page.screenshot({ path: 'test_before_save.png', fullPage: false });
    console.log("\n✓ Screenshot pre-guardado: test_before_save.png");

    // 11. Read hidden field values to verify they're set
    console.log("\n11. Verificando valores de campos ocultos...");
    const hiddenValues = await page.evaluate(() => {
      return {
        rodado_id: document.querySelector('input[name="rodado_id"]')?.value || '(empty)',
        syj_empleado_id: document.querySelector('input[name="syj_empleado_id"]')?.value || '(empty)',
        fecha: document.querySelector('input[name="fecha"]')?.value || '(empty)',
        titulo: document.querySelector('input[name="titulo"]')?.value || '(empty)',
        inv_ot_clasificacion_id: document.querySelector('select[name="inv_ot_clasificacion_id"]')?.value || '(empty)',
        descripcion: document.querySelector('textarea[name="descripcion"]')?.value || '(empty)',
      };
    });
    console.log("   Hidden values:", JSON.stringify(hiddenValues, null, 2));

    // Check if required hidden fields have values
    if (hiddenValues.rodado_id === '(empty)' || hiddenValues.rodado_id === '') {
      console.log("\n⚠ WARNING: rodado_id is empty! The form will likely fail validation.");
    }
    if (hiddenValues.syj_empleado_id === '(empty)' || hiddenValues.syj_empleado_id === '') {
      console.log("\n⚠ WARNING: syj_empleado_id is empty! The form will likely fail validation.");
    }

    // 12. CLICK GUARDAR
    console.log("\n12. Haciendo clic en Guardar...");
    const saveClicked = await page.evaluate(() => {
      const btn = document.querySelector('.taxes-btn-save');
      if (btn) {
        btn.click();
        return true;
      }
      // Fallback
      const buttons = Array.from(document.querySelectorAll('button'));
      const guardar = buttons.find(b => b.textContent.trim() === 'Guardar');
      if (guardar) {
        guardar.click();
        return true;
      }
      return false;
    });
    console.log(`   Guardar clicked: ${saveClicked}`);

    // Wait for response
    await delay(5000);

    // Take screenshot after saving
    await page.screenshot({ path: 'test_after_save.png', fullPage: false });
    console.log("✓ Screenshot post-guardado: test_after_save.png");

    // Check for validation errors
    const errors = await page.evaluate(() => {
      const alertElements = document.querySelectorAll('.alert, .is-invalid, .invalid-feedback, .error, .text-danger, [class*="error"], [class*="alert"]');
      return Array.from(alertElements).map(el => el.textContent.trim()).filter(t => t.length > 0 && t.length < 200);
    });
    
    if (errors.length > 0) {
      console.log("\n⚠ ERRORES DE VALIDACIÓN DETECTADOS:");
      errors.forEach(e => console.log(`   - ${e}`));
    }

    // Check current URL to see if we were redirected (success usually redirects)
    const currentUrl = page.url();
    console.log(`\nURL actual: ${currentUrl}`);

    // Check page content for success indicators
    const pageContent = await page.evaluate(() => document.body.innerText.substring(0, 500));
    console.log(`\nContenido de página: ${pageContent.substring(0, 300)}`);

    console.log("\n=== Navegador abierto 30 segundos para inspección ===");
    await delay(30000);

    await browser.close();
    console.log("\n✓ Test completado.");
  } catch (error) {
    console.error("Error:", error);
    if (browser) await browser.close();
  }
}

/**
 * Fill a searchable select field on Taxes.com.ar
 * These fields have:
 * - A visible text input (class="form-control searchable-input") 
 * - A hidden input with the actual value (name="rodado_id" or "syj_empleado_id")
 * - A dropdown that appears when you type
 */
async function fillSearchableSelectField(page, labelText, searchQuery, hiddenInputName) {
  console.log(`   Buscando campo "${labelText}" con query "${searchQuery}"...`);
  
  try {
    // Find the correct searchable-input by looking at the label
    const inputInfo = await page.evaluate((label, hiddenName) => {
      // Find all form-groups or containers that have a label matching the text
      const allLabels = Array.from(document.querySelectorAll('label'));
      for (const lbl of allLabels) {
        if (lbl.textContent.trim().toLowerCase().includes(label.toLowerCase())) {
          // Find the parent container
          const parent = lbl.closest('.form-group') || lbl.closest('.taxes-form-group') || lbl.parentElement;
          if (parent) {
            // Look for the searchable-input inside this container
            const searchInput = parent.querySelector('.searchable-input');
            const hiddenInput = parent.querySelector(`input[name="${hiddenName}"]`);
            
            if (searchInput && hiddenInput) {
              // Give them temporary IDs for reliable selection
              const searchId = 'tmp_search_' + Date.now();
              const hiddenId = 'tmp_hidden_' + Date.now();
              searchInput.setAttribute('id', searchId);
              hiddenInput.setAttribute('id', hiddenId);
              return { searchId, hiddenId, found: true };
            }
          }
        }
      }
      return { found: false };
    }, labelText, hiddenInputName);

    if (!inputInfo.found) {
      console.log(`   ⚠ No se encontró campo searchable para "${labelText}"`);
      return false;
    }

    const searchSelector = `#${inputInfo.searchId}`;
    const hiddenSelector = `#${inputInfo.hiddenId}`;

    // Click and clear the searchable input
    await page.click(searchSelector);
    await delay(300);
    await page.focus(searchSelector);
    await page.keyboard.down('Control');
    await page.keyboard.press('A');
    await page.keyboard.up('Control');
    await page.keyboard.press('Backspace');
    await delay(200);

    // Type the search query
    await page.type(searchSelector, searchQuery, { delay: 80 });
    await delay(2000); // Wait for dropdown to appear and filter

    // Take screenshot of dropdown
    await page.screenshot({ path: `test_dropdown_${labelText.toLowerCase()}.png`, fullPage: false });

    // Click the first visible option in the dropdown
    const optionClicked = await page.evaluate((hiddenName) => {
      // Find dropdown containers
      const dropdowns = Array.from(document.querySelectorAll('[id^="searchable-select-dropdown-"]'));
      
      for (const dropdown of dropdowns) {
        const isVisible = dropdown.offsetWidth > 0 && dropdown.offsetHeight > 0;
        if (!isVisible) continue;
        
        // Find all clickable option divs
        const options = Array.from(dropdown.querySelectorAll('div'));
        const validOptions = options.filter(d => {
          const text = d.textContent.trim();
          // Filter out headers, empty items, loading states
          if (text.length === 0) return false;
          if (text.includes('opciones') || text.includes('cargando') || text.includes('No hay')) return false;
          // Must be a leaf div (no child divs with content)
          const childDivs = Array.from(d.querySelectorAll('div')).filter(cd => cd.textContent.trim().length > 0);
          return childDivs.length === 0;
        });

        if (validOptions.length > 0) {
          const selected = validOptions[0];
          const selectedText = selected.textContent.trim();
          selected.click();
          return { success: true, text: selectedText };
        }
      }
      
      // Fallback: try any visible option-like elements
      const fallbackOptions = document.querySelectorAll('.searchable-select-option, [role="option"]');
      for (const opt of fallbackOptions) {
        if (opt.offsetWidth > 0 && opt.textContent.trim().length > 0) {
          opt.click();
          return { success: true, text: opt.textContent.trim() };
        }
      }
      
      return { success: false };
    }, hiddenInputName);

    if (optionClicked.success) {
      console.log(`   ✓ Opción seleccionada: "${optionClicked.text}"`);
      
      // Wait for Vue reactivity to update the hidden input
      await delay(1000);
      
      // Verify the hidden input got a value
      const hiddenValue = await page.evaluate((sel) => {
        const el = document.querySelector(sel);
        return el ? el.value : '(not found)';
      }, hiddenSelector);
      console.log(`   ✓ Hidden input value: "${hiddenValue}"`);
      
      return hiddenValue !== '' && hiddenValue !== '(not found)';
    } else {
      console.log(`   ⚠ No se encontró ninguna opción en el dropdown`);
      return false;
    }
  } catch (error) {
    console.error(`   Error en searchable select "${labelText}":`, error.message);
    return false;
  }
}

testCreateOT();
