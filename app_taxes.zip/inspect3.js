const puppeteer = require('puppeteer');
const db = require('./database');

async function inspect() {
  const settings = db.getSettings();
  console.log("Using credentials:", settings.username);
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // 1. LOGIN
    console.log("Navigating to portal admin...");
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });
    
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('BELOCURES') || 
             document.body.textContent.includes('Inicio') || 
             document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      console.log("Logging in...");
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if ((type === 'text' || type === 'email' || name.includes('email') || name.includes('user'))) {
          await input.focus();
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.focus();
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 20000 }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }

    console.log("Login done. Current URL:", page.url());

    // 2. Navigate to ORDENES DE TRABAJO (correct URL!)
    console.log("\n=== Navigating to Ordenes de Trabajo ===");
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2', timeout: 30000 });
    await new Promise(res => setTimeout(res, 3000));
    console.log("Current URL:", page.url());
    await page.screenshot({ path: 'inspect_ot_list.png', fullPage: true });

    // 3. Find the "NUEVO" button and click it
    console.log("\n=== Looking for NUEVO button ===");
    const allBtns = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('button, a')).map(b => ({
        tag: b.tagName,
        text: b.textContent.trim().substring(0, 60),
        className: b.className,
        href: b.href || ''
      })).filter(b => b.text.toLowerCase().includes('nuevo') || b.text.toLowerCase().includes('nueva') || b.text.toLowerCase().includes('agregar') || b.text.toLowerCase().includes('crear') || b.className.includes('success'));
    });
    console.log("Relevant buttons found:", JSON.stringify(allBtns, null, 2));

    // Click the NUEVO button
    const nuevoClicked = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      for (const btn of buttons) {
        if (btn.textContent.trim().toUpperCase().includes('NUEVO') || btn.textContent.trim().toUpperCase().includes('NUEVA')) {
          btn.click();
          return btn.textContent.trim();
        }
      }
      return null;
    });
    console.log("Clicked NUEVO button:", nuevoClicked);
    await new Promise(res => setTimeout(res, 5000));

    console.log("URL after NUEVO click:", page.url());
    await page.screenshot({ path: 'inspect_ot_create.png', fullPage: true });

    // 4. Deep analysis of the create form
    console.log("\n=== CREATE OT FORM ANALYSIS ===");
    const formAnalysis = await page.evaluate(() => {
      const result = {
        url: window.location.href,
        title: document.title,
        headings: Array.from(document.querySelectorAll('h1, h2, h3, h4, h5')).map(h => h.textContent.trim()).filter(t => t.length > 0 && t.length < 100),
        allLabels: Array.from(document.querySelectorAll('label')).map(l => ({
          text: l.textContent.trim(),
          for: l.htmlFor,
          className: l.className,
          parentClass: l.parentElement ? l.parentElement.className : ''
        })).filter(l => l.text.length > 0),
        selects: Array.from(document.querySelectorAll('select')).map(s => ({
          id: s.id,
          name: s.name,
          className: s.className,
          optionCount: s.options.length,
          options: Array.from(s.options).slice(0, 15).map(o => ({ value: o.value, text: o.textContent.trim() })),
          labels: s.labels ? Array.from(s.labels).map(l => l.textContent.trim()) : [],
          parentClass: s.parentElement ? s.parentElement.className : '',
          grandParentClass: s.parentElement && s.parentElement.parentElement ? s.parentElement.parentElement.className : ''
        })),
        inputs: Array.from(document.querySelectorAll('input:not([type="hidden"])')).map(i => ({
          id: i.id,
          name: i.name,
          type: i.type,
          placeholder: i.placeholder,
          className: i.className,
          value: i.value,
          labels: i.labels ? Array.from(i.labels).map(l => l.textContent.trim()) : [],
          parentClass: i.parentElement ? i.parentElement.className : ''
        })),
        textareas: Array.from(document.querySelectorAll('textarea')).map(t => ({
          id: t.id,
          name: t.name,
          placeholder: t.placeholder,
          className: t.className,
          labels: t.labels ? Array.from(t.labels).map(l => l.textContent.trim()) : [],
          parentClass: t.parentElement ? t.parentElement.className : ''
        })),
        // Look for vue-select or searchable components  
        searchableSelects: Array.from(document.querySelectorAll('.searchable-select-wrapper, .vs__dropdown-toggle, .v-select, [class*="searchable"], .multiselect')).map(el => ({
          tag: el.tagName,
          className: el.className,
          id: el.id,
          text: el.textContent.trim().substring(0, 150),
          innerHTML: el.innerHTML.substring(0, 300)
        })),
        // Buttons
        buttons: Array.from(document.querySelectorAll('button')).map(b => ({
          text: b.textContent.trim().substring(0, 60),
          type: b.type,
          className: b.className
        })).filter(b => b.text.length > 0),
        // Check for modals that might be open
        modals: Array.from(document.querySelectorAll('.modal, .b-modal, [role="dialog"]')).map(m => ({
          id: m.id,
          className: m.className,
          display: window.getComputedStyle(m).display,
          visible: m.offsetWidth > 0
        }))
      };
      return result;
    });

    console.log("\n--- URL:", formAnalysis.url);
    console.log("--- Title:", formAnalysis.title);
    console.log("--- Headings:", JSON.stringify(formAnalysis.headings));
    console.log("--- Modals:", JSON.stringify(formAnalysis.modals));
    
    console.log("\n--- LABELS (" + formAnalysis.allLabels.length + "):");
    formAnalysis.allLabels.forEach(l => console.log("  ", JSON.stringify(l)));
    
    console.log("\n--- SELECTS (" + formAnalysis.selects.length + "):");
    formAnalysis.selects.forEach(s => console.log("  ", JSON.stringify(s)));
    
    console.log("\n--- INPUTS (" + formAnalysis.inputs.length + "):");
    formAnalysis.inputs.forEach(i => console.log("  ", JSON.stringify(i)));
    
    console.log("\n--- TEXTAREAS (" + formAnalysis.textareas.length + "):");
    formAnalysis.textareas.forEach(t => console.log("  ", JSON.stringify(t)));
    
    console.log("\n--- SEARCHABLE SELECTS (" + formAnalysis.searchableSelects.length + "):");
    formAnalysis.searchableSelects.forEach(s => console.log("  ", JSON.stringify(s)));

    console.log("\n--- BUTTONS (" + formAnalysis.buttons.length + "):");
    formAnalysis.buttons.forEach(b => console.log("  ", JSON.stringify(b)));

    // 5. Get main content HTML structure
    const mainHTML = await page.evaluate(() => {
      // Try to get the main form area
      const modal = document.querySelector('.modal.show, .b-modal .modal-dialog, .modal[style*="display: block"]');
      if (modal) return "MODAL FOUND:\n" + modal.innerHTML.substring(0, 10000);
      
      const mainContent = document.querySelector('.content-wrapper, .main-content, main, .app-content');
      if (mainContent) return "MAIN CONTENT:\n" + mainContent.innerHTML.substring(0, 10000);
      
      // Fallback: look for forms
      const forms = document.querySelectorAll('form');
      if (forms.length > 0) {
        return "FORMS FOUND:\n" + Array.from(forms).map(f => `FORM(${f.id}): ${f.innerHTML.substring(0, 3000)}`).join('\n---\n');
      }
      
      return "BODY SNIPPET:\n" + document.body.innerHTML.substring(0, 10000);
    });
    console.log("\n=== MAIN CONTENT HTML ===");
    console.log(mainHTML);

  } catch (error) {
    console.error("Inspection error:", error);
  } finally {
    await browser.close();
  }
}

inspect();
