const puppeteer = require('puppeteer');
const db = require('./database');

async function inspectDropdown() {
  const settings = db.getSettings();
  console.log("Using credentials:", settings.username);
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // Login
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Inicio') || document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if (type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) {
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }

    // Go to OT list and click NUEVO
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2' });
    await new Promise(res => setTimeout(res, 3000));
    
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const nuevo = buttons.find(b => b.textContent.trim().toUpperCase().includes('NUEVO'));
      if (nuevo) nuevo.click();
    });
    await new Promise(res => setTimeout(res, 3000));

    // Find Rodado searchable input and click it
    const inputSelector = await page.evaluate(() => {
      const groups = Array.from(document.querySelectorAll('.form-group, .taxes-form-group'));
      const rodadoGroup = groups.find(g => g.textContent.toLowerCase().includes('rodado'));
      if (rodadoGroup) {
        const input = rodadoGroup.querySelector('.searchable-input, input[type="text"]');
        if (input) {
          input.setAttribute('id', 'test_rodado_input');
          return '#test_rodado_input';
        }
      }
      return null;
    });

    if (inputSelector) {
      console.log("Found Rodado input, clicking and typing...");
      await page.click(inputSelector);
      await new Promise(res => setTimeout(res, 500));
      await page.type(inputSelector, "FORD", { delay: 100 });
      await new Promise(res => setTimeout(res, 3000)); // Wait for dropdown to filter

      // Log all elements that might be dropdown options
      const dropdownElements = await page.evaluate(() => {
        // Let's grab all divs, lists, spans and anchors that are rendered
        // inside the searchable select or appended to body that are visible
        const all = Array.from(document.querySelectorAll('*'));
        return all.map(el => {
          const isVisible = el.offsetWidth > 0 || window.getComputedStyle(el).display !== 'none';
          const hasClasses = el.className && typeof el.className === 'string' && el.className.trim().length > 0;
          return {
            tagName: el.tagName,
            id: el.id,
            className: el.className,
            text: el.textContent.trim().substring(0, 80),
            isVisible,
            hasClasses
          };
        }).filter(item => {
          // Filter items that look like options or are inside lists or containers with classes that contain search, select, option, or dropdown
          const isSearchDropdown = item.className && typeof item.className === 'string' && (
            item.className.includes('search') || 
            item.className.includes('select') || 
            item.className.includes('option') || 
            item.className.includes('dropdown') || 
            item.className.includes('menu') ||
            item.className.includes('item')
          );
          return item.isVisible && isSearchDropdown && item.text.length > 0 && item.text.length < 200;
        });
      });

      console.log("=== DROP-DOWN ELEMENTS DETECTED ===");
      console.log(JSON.stringify(dropdownElements, null, 2));

      // Let's also take a screenshot of the opened dropdown to see visually!
      await page.screenshot({ path: 'inspect_opened_dropdown.png' });
      console.log("Screenshot saved to inspect_opened_dropdown.png");

    } else {
      console.log("Rodado input not found!");
    }

  } catch (error) {
    console.error("Error inspecting dropdown:", error);
  } finally {
    await browser.close();
  }
}

inspectDropdown();
