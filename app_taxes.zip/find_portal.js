const puppeteer = require('puppeteer');
const db = require('./database');

async function findDropdownPortal() {
  const settings = db.getSettings();
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // Login
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Inicio') || document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if (type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) {
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }

    // Go to OT list and click NUEVO
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2' });
    await new Promise(res => setTimeout(res, 3000));
    
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const nuevo = buttons.find(b => b.textContent.trim().toUpperCase().includes('NUEVO'));
      if (nuevo) nuevo.click();
    });
    await new Promise(res => setTimeout(res, 3000));

    // Find Rodado searchable input and click it
    const inputSelector = await page.evaluate(() => {
      const groups = Array.from(document.querySelectorAll('.form-group, .taxes-form-group'));
      const rodadoGroup = groups.find(g => g.textContent.toLowerCase().includes('rodado'));
      if (rodadoGroup) {
        const input = rodadoGroup.querySelector('.searchable-input, input[type="text"]');
        if (input) {
          input.setAttribute('id', 'test_rodado_input3');
          return '#test_rodado_input3';
        }
      }
      return null;
    });

    if (inputSelector) {
      await page.click(inputSelector);
      await new Promise(res => setTimeout(res, 500));
      await page.type(inputSelector, "FORD", { delay: 100 });
      await new Promise(res => setTimeout(res, 3000)); // Wait for dropdown to filter

      // Log direct body children to find the portal
      const bodyChildren = await page.evaluate(() => {
        return Array.from(document.body.children).map((el, index) => ({
          index,
          tagName: el.tagName,
          id: el.id,
          className: el.className,
          text: el.textContent.trim().substring(0, 100),
          htmlSnippet: el.outerHTML.substring(0, 300)
        }));
      });

      console.log("=== BODY DIRECT CHILDREN ===");
      console.log(JSON.stringify(bodyChildren, null, 2));

      // Let's also look for all visible elements containing 'FORD'
      const matches = await page.evaluate(() => {
        const all = Array.from(document.querySelectorAll('*'));
        return all.filter(el => {
          const text = el.textContent.trim();
          const isOption = text.includes('FORD - F100. Interno 1') && el.offsetWidth > 0;
          return isOption;
        }).map(el => ({
          tagName: el.tagName,
          id: el.id,
          className: el.className,
          text: el.textContent.trim().substring(0, 100),
          parentClass: el.parentElement ? el.parentElement.className : ''
        }));
      });

      console.log("=== ALL VISIBLE ELEMENTS MATCHING 'FORD - F100. Interno 1' ===");
      console.log(JSON.stringify(matches, null, 2));
    }

  } catch (error) {
    console.error("Error finding portal:", error);
  } finally {
    await browser.close();
  }
}

findDropdownPortal();
