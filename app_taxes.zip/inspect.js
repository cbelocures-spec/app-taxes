const puppeteer = require('puppeteer');
const db = require('./database');

async function inspect() {
  const settings = db.getSettings();
  console.log("Using credentials:", settings.username);
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    console.log("Navigating to portal admin...");
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });

    // Check login
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('BELOCURES') || 
             document.body.textContent.includes('Inicio') || 
             document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      console.log("Logging in...");
      const inputs = await page.$$('input');
      let usernameFilled = false;
      let passwordFilled = false;

      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        
        if ((type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) && !usernameFilled) {
          await input.focus();
          await input.type(settings.username);
          usernameFilled = true;
        } else if ((type === 'password' || name.includes('pass')) && !passwordFilled) {
          await input.focus();
          await input.type(settings.password);
          passwordFilled = true;
        }
      }

      console.log("Clicking submit...");
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 20000 }).catch(() => {});
      await new Promise(res => setTimeout(res, 5000));
    }

    console.log("Navigating to create order page...");
    // Let's go to workshop -> create order
    await page.goto(`${settings.portalUrl}/admin/taller/ordenes-trabajo/create`, { waitUntil: 'networkidle2', timeout: 30000 }).catch(async (e) => {
      console.log("Direct navigation failed, attempting to navigate via clicks...", e.message);
    });

    await new Promise(res => setTimeout(res, 5000));
    
    // Dump URL to check where we are
    const currentUrl = page.url();
    console.log("Current URL:", currentUrl);

    // Save screenshot
    const screenshotPath = 'inspect_page.png';
    await page.screenshot({ path: screenshotPath, fullPage: true });
    console.log("Screenshot saved to:", screenshotPath);

    // Analyze forms and elements
    const elementsInfo = await page.evaluate(() => {
      const inputs = Array.from(document.querySelectorAll('input, select, textarea, button'));
      return inputs.map(el => {
        return {
          tagName: el.tagName,
          id: el.id,
          name: el.name || el.getAttribute('name'),
          type: el.type,
          placeholder: el.getAttribute('placeholder'),
          className: el.className,
          labels: el.labels ? Array.from(el.labels).map(l => l.textContent.trim()) : [],
          text: el.textContent ? el.textContent.trim().substring(0, 100) : ''
        };
      });
    });

    console.log("HTML Form elements found:", JSON.stringify(elementsInfo, null, 2));

  } catch (error) {
    console.error("Inspection error:", error);
  } finally {
    await browser.close();
  }
}

inspect();
