const puppeteer = require('puppeteer');
const db = require('./database');

async function inspect() {
  const settings = db.getSettings();
  console.log("Using credentials:", settings.username);
  
  const browser = await puppeteer.launch({
    headless: false,  // visible for debugging
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--window-size=1400,1000']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // 1. LOGIN
    console.log("Navigating to portal admin...");
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2', timeout: 30000 });
    
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('BELOCURES') || 
             document.body.textContent.includes('Inicio') || 
             document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      console.log("Logging in...");
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if ((type === 'text' || type === 'email' || name.includes('email') || name.includes('user'))) {
          await input.focus();
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.focus();
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 20000 }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }

    console.log("Login done. Current URL:", page.url());
    
    // 2. Explore sidebar: find all <a> links
    console.log("\n=== ALL LINKS ON PAGE ===");
    const allLinks = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('a')).map(a => ({
        text: a.textContent.trim().substring(0, 80),
        href: a.href,
        className: a.className
      }));
    });
    allLinks.forEach(l => console.log(`  [${l.text}] -> ${l.href}`));

    // 3. Find and click "Taller" link
    console.log("\n=== Clicking on Taller ===");
    const tallerClicked = await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('a'));
      for (const link of links) {
        if (link.textContent.trim().toLowerCase().includes('taller')) {
          console.log("Found taller link:", link.href);
          link.click();
          return link.href;
        }
      }
      return null;
    });
    console.log("Taller link clicked:", tallerClicked);
    await new Promise(res => setTimeout(res, 3000));
    
    console.log("URL after Taller click:", page.url());
    await page.screenshot({ path: 'inspect_after_taller.png', fullPage: true });

    // 4. Find all links again (sub-menu might have appeared)
    console.log("\n=== ALL LINKS AFTER TALLER ===");
    const allLinks2 = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('a')).map(a => ({
        text: a.textContent.trim().substring(0, 80),
        href: a.href
      }));
    });
    allLinks2.forEach(l => console.log(`  [${l.text}] -> ${l.href}`));

    // 5. Try to click "Ordenes de Trabajo" or similar
    console.log("\n=== Clicking on 'Ordenes' link ===");
    const ordenesClicked = await page.evaluate(() => {
      const links = Array.from(document.querySelectorAll('a'));
      for (const link of links) {
        const txt = link.textContent.trim().toLowerCase();
        if (txt.includes('ordenes') || txt.includes('órdenes') || txt.includes('orden de trabajo')) {
          link.click();
          return { text: link.textContent.trim(), href: link.href };
        }
      }
      return null;
    });
    console.log("Ordenes link clicked:", JSON.stringify(ordenesClicked));
    await new Promise(res => setTimeout(res, 3000));

    console.log("URL after Ordenes click:", page.url());
    await page.screenshot({ path: 'inspect_after_ordenes.png', fullPage: true });

    // 6. Find all links/buttons on orders page (for "Agregar", "Nueva", "Crear")
    console.log("\n=== ALL LINKS/BUTTONS ON ORDERS PAGE ===");
    const allElements = await page.evaluate(() => {
      const result = [];
      const links = Array.from(document.querySelectorAll('a'));
      links.forEach(a => result.push({ tag: 'a', text: a.textContent.trim().substring(0, 80), href: a.href }));
      const buttons = Array.from(document.querySelectorAll('button'));
      buttons.forEach(b => result.push({ tag: 'button', text: b.textContent.trim().substring(0, 80), className: b.className }));
      return result;
    });
    allElements.forEach(e => console.log(`  [${e.tag}] "${e.text}" -> ${e.href || e.className || ''}`));

    // 7. Try to click "Agregar OT" or similar button
    console.log("\n=== Clicking 'Agregar' button/link ===");
    const addClicked = await page.evaluate(() => {
      // First, try buttons
      const buttons = Array.from(document.querySelectorAll('button, a'));
      for (const btn of buttons) {
        const txt = btn.textContent.trim().toLowerCase();
        if (txt.includes('agregar') || txt.includes('nueva') || txt.includes('crear') || txt.includes('new') || txt.includes('add')) {
          btn.click();
          return { tag: btn.tagName, text: btn.textContent.trim(), href: btn.href || '' };
        }
      }
      return null;
    });
    console.log("Add button clicked:", JSON.stringify(addClicked));
    await new Promise(res => setTimeout(res, 5000));

    console.log("URL after Add click:", page.url());
    await page.screenshot({ path: 'inspect_create_form.png', fullPage: true });

    // 8. Now analyze the CREATE form page in depth
    console.log("\n=== FORM PAGE DEEP ANALYSIS ===");
    const formAnalysis = await page.evaluate(() => {
      const result = {
        url: window.location.href,
        title: document.title,
        h1: Array.from(document.querySelectorAll('h1, h2, h3, h4')).map(h => h.textContent.trim()),
        forms: Array.from(document.querySelectorAll('form')).map(f => ({
          id: f.id,
          action: f.action,
          method: f.method
        })),
        selects: Array.from(document.querySelectorAll('select')).map(s => ({
          id: s.id,
          name: s.name,
          className: s.className,
          optionCount: s.options.length,
          options: Array.from(s.options).slice(0, 10).map(o => ({ value: o.value, text: o.textContent.trim() })),
          labels: s.labels ? Array.from(s.labels).map(l => l.textContent.trim()) : [],
          parentInfo: s.parentElement ? s.parentElement.className : ''
        })),
        inputs: Array.from(document.querySelectorAll('input')).map(i => ({
          id: i.id,
          name: i.name,
          type: i.type,
          placeholder: i.placeholder,
          className: i.className,
          labels: i.labels ? Array.from(i.labels).map(l => l.textContent.trim()) : [],
          parentInfo: i.parentElement ? i.parentElement.className : ''
        })),
        textareas: Array.from(document.querySelectorAll('textarea')).map(t => ({
          id: t.id,
          name: t.name,
          placeholder: t.placeholder,
          labels: t.labels ? Array.from(t.labels).map(l => l.textContent.trim()) : []
        })),
        // Look for custom dropdown components (Vue/React)
        vueSelects: Array.from(document.querySelectorAll('.vs__dropdown-toggle, .v-select, [class*="select"], [class*="dropdown"], [class*="combo"]')).map(el => ({
          tag: el.tagName,
          className: el.className,
          text: el.textContent.trim().substring(0, 100),
          id: el.id,
          parentClass: el.parentElement ? el.parentElement.className : ''
        })),
        // Look for labels to understand form structure
        allLabels: Array.from(document.querySelectorAll('label')).map(l => ({
          text: l.textContent.trim(),
          for: l.htmlFor,
          className: l.className
        })),
        buttons: Array.from(document.querySelectorAll('button')).map(b => ({
          text: b.textContent.trim().substring(0, 80),
          type: b.type,
          className: b.className
        }))
      };
      return result;
    });

    console.log("\n--- URL:", formAnalysis.url);
    console.log("--- Title:", formAnalysis.title);
    console.log("--- Headings:", JSON.stringify(formAnalysis.h1));
    console.log("--- Forms:", JSON.stringify(formAnalysis.forms));
    console.log("\n--- SELECTS (" + formAnalysis.selects.length + "):");
    formAnalysis.selects.forEach(s => console.log("  ", JSON.stringify(s)));
    console.log("\n--- INPUTS (" + formAnalysis.inputs.length + "):");
    formAnalysis.inputs.forEach(i => console.log("  ", JSON.stringify(i)));
    console.log("\n--- TEXTAREAS (" + formAnalysis.textareas.length + "):");
    formAnalysis.textareas.forEach(t => console.log("  ", JSON.stringify(t)));
    console.log("\n--- VUE/CUSTOM SELECTS (" + formAnalysis.vueSelects.length + "):");
    formAnalysis.vueSelects.forEach(v => console.log("  ", JSON.stringify(v)));
    console.log("\n--- LABELS (" + formAnalysis.allLabels.length + "):");
    formAnalysis.allLabels.forEach(l => console.log("  ", JSON.stringify(l)));
    console.log("\n--- BUTTONS (" + formAnalysis.buttons.length + "):");
    formAnalysis.buttons.forEach(b => console.log("  ", JSON.stringify(b)));

    // 9. Dump full page HTML structure (first 5000 chars of the main content area)
    const pageBodySnippet = await page.evaluate(() => {
      const main = document.querySelector('main, .content, .container, #app, #root, .main-content');
      if (main) return main.innerHTML.substring(0, 8000);
      return document.body.innerHTML.substring(0, 8000);
    });
    console.log("\n=== PAGE HTML SNIPPET (first 8000 chars) ===");
    console.log(pageBodySnippet);

  } catch (error) {
    console.error("Inspection error:", error);
  } finally {
    await browser.close();
  }
}

inspect();
