const url = "https://script.google.com/macros/s/AKfycbwyeeYxtKWq1gxDxPeOjWFGaVyNt_y81WYJwZNPdb1hmYgBVV7ssZ0SaRfNqwhPr39lIQ/exec";

const queryParams = new URLSearchParams({
  interno: "91",
  rubro: "Electricidad",
  subrubro: "Luces",
  observacion: "",
  mecanico: "Cuba Orosco, Kevín Genaro",
  supervisor: "Belocures, Cesar Hernán"
});

const testUrl = `${url}?${queryParams.toString()}`;
console.log("Testing URL:", testUrl);

fetch(testUrl)
  .then(async (res) => {
    const text = await res.text();
    console.log("Status:", res.status);
    console.log("Response:", text);
  })
  .catch(err => {
    console.error("Error:", err.message);
  });
