const puppeteer = require('puppeteer');
const db = require('../database');

async function run() {
  const settings = db.getSettings();
  console.log("Launching browser...");
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 800 });
    
    console.log(`Navigating to ${settings.portalUrl}/admin ...`);
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    
    console.log("Checking login status...");
    const inputs = await page.$$('input');
    let usernameFilled = false;
    let passwordFilled = false;
    for (const input of inputs) {
      const type = await page.evaluate(el => el.type, input);
      if ((type === 'text' || type === 'email') && !usernameFilled) {
        await input.type(settings.username);
        usernameFilled = true;
      } else if (type === 'password' && !passwordFilled) {
        await input.type(settings.password);
        passwordFilled = true;
      }
    }
    
    console.log("Clicking login...");
    await page.keyboard.press('Enter');
    await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
    await new Promise(r => setTimeout(r, 4000));
    
    console.log("Logged in successfully. Inspecting sidebar / menu links...");
    const links = await page.evaluate(() => {
      const results = [];
      const anchors = Array.from(document.querySelectorAll('a'));
      for (const a of anchors) {
        const text = a.textContent.trim().replace(/\s+/g, ' ');
        const href = a.getAttribute('href') || '';
        if (text || href) {
          results.push({ text, href });
        }
      }
      return results;
    });
    
    console.log("Found links:");
    links.forEach(l => {
      if (l.text.toLowerCase().includes('flota') || l.href.toLowerCase().includes('flota')) {
        console.log(`[MATCH] Text: "${l.text}" | Href: "${l.href}"`);
      } else {
        console.log(`Text: "${l.text}" | Href: "${l.href}"`);
      }
    });
    
  } catch (err) {
    console.error("Error:", err);
  } finally {
    await browser.close();
    console.log("Done.");
  }
}

run();
