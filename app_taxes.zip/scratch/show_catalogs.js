const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '../db.json');
const data = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

console.log("=== Responsables Catalog ===");
console.log(JSON.stringify(data.catalogs.responsables.slice(0, 10), null, 2));

console.log("\n=== Empleados Catalog Sample ===");
console.log(JSON.stringify(data.catalogs.empleados.slice(0, 10), null, 2));
