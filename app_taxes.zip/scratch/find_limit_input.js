const puppeteer = require('puppeteer');
const db = require('../database');

async function run() {
  const settings = db.getSettings();
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    
    // login
    const inputs = await page.$$('input');
    let u = false, p = false;
    for (const input of inputs) {
      const type = await page.evaluate(el => el.type, input);
      if ((type === 'text' || type === 'email') && !u) { await input.type(settings.username); u = true; }
      else if (type === 'password' && !p) { await input.type(settings.password); p = true; }
    }
    await page.keyboard.press('Enter');
    await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
    await new Promise(r => setTimeout(r, 3000));
    
    // navigate to flota
    await page.goto(`${settings.portalUrl}/tms/produccion/flota`, { waitUntil: 'networkidle2' });
    await new Promise(r => setTimeout(r, 3000));
    
    // print all input elements
    const inputsDetails = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('input, select, textarea')).map((el, i) => {
        return {
          index: i,
          tagName: el.tagName,
          id: el.id,
          name: el.name || el.getAttribute('name'),
          type: el.type || el.getAttribute('type'),
          className: el.className,
          placeholder: el.getAttribute('placeholder'),
          value: el.value,
          outerHTML: el.outerHTML.substring(0, 300)
        };
      });
    });
    
    console.log("ALL INPUT ELEMENTS:");
    console.log(JSON.stringify(inputsDetails, null, 2));
    
  } catch (err) {
    console.error(err);
  } finally {
    await browser.close();
  }
}

run();
