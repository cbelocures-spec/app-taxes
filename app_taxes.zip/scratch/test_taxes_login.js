const puppeteer = require('puppeteer');

async function testLogin() {
  const username = 'a.brahim@contenedoreshugo.com.ar';
  const password = '123456';
  const portalUrl = 'https://taxes.com.ar';

  console.log(`Launching Puppeteer to test login for ${username}...`);
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 900 });

    console.log(`Navigating to ${portalUrl}...`);
    await page.goto(portalUrl, { waitUntil: 'networkidle2', timeout: 30000 });

    console.log("Checking if already logged in...");
    const loggedInEmail = await page.evaluate(() => {
      const el = document.querySelector('.user-profile, .profile-info, .username, #user-name-display');
      if (el) return el.textContent.trim();
      const bodyText = document.body.innerText;
      const match = bodyText.match(/[a-zA-Z0-9._%+-]+@contenedoreshugo\.com\.ar/i);
      return match ? match[0] : null;
    });

    if (loggedInEmail) {
      console.log(`Already logged in as: ${loggedInEmail}`);
    } else {
      console.log("Filling login form...");
      
      // Let's find inputs
      await page.evaluate((u, p) => {
        const inputs = Array.from(document.querySelectorAll('input'));
        let userFilled = false;
        let passFilled = false;
        for (const input of inputs) {
          const type = input.getAttribute('type') || '';
          const name = input.getAttribute('name') || '';
          const id = input.getAttribute('id') || '';
          if ((type === 'text' || type === 'email' || name.includes('email') || name.includes('user') || id.includes('user')) && !userFilled) {
            input.value = u;
            userFilled = true;
          } else if ((type === 'password' || name.includes('pass') || id.includes('pass')) && !passFilled) {
            input.value = p;
            passFilled = true;
          }
        }
      }, username, password);

      // Take a screenshot before click
      await page.screenshot({ path: 'scratch/before_login_click.png' });
      
      // Submit form
      console.log("Submitting form...");
      await page.evaluate(() => {
        const btn = document.querySelector('button[type="submit"], input[type="submit"]');
        if (btn) btn.click();
        else {
          const form = document.querySelector('form');
          if (form) form.submit();
        }
      });

      console.log("Waiting for navigation or changes...");
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 10000 }).catch(() => {
        console.log("Navigation timeout, checking page URL...");
      });

      console.log("Current URL:", page.url());
      await page.screenshot({ path: 'scratch/after_login_click.png' });

      const bodyText = await page.evaluate(() => document.body.innerText);
      const isLoginFailed = bodyText.toLowerCase().includes('inválido') || 
                            bodyText.toLowerCase().includes('incorrecto') || 
                            bodyText.toLowerCase().includes('error') ||
                            bodyText.toLowerCase().includes('usuario o contraseña');
      
      console.log("Does body contain error message?", isLoginFailed);
      if (isLoginFailed) {
        console.log("Login failed on Taxes portal.");
      } else {
        console.log("Login looks successful!");
      }
    }
  } catch (err) {
    console.error("Puppeteer test failed:", err);
  } finally {
    await browser.close();
  }
}

testLogin();
