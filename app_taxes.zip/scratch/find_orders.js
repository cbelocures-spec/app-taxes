const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '../db.json');
const data = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

console.log("=== Settings ===");
console.log(JSON.stringify(data.settings, null, 2));

console.log("\n=== Work Orders matching 91 ===");
const matched = (data.workOrders || []).filter(o => o.interno === '91');
console.log(JSON.stringify(matched, null, 2));
