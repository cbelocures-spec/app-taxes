const fs = require('fs');
const path = require('path');
const db = require('../database');

// We need to temporarily mock db.getSettings and fetch to test server.js functions
const serverCode = fs.readFileSync(path.join(__dirname, '../server.js'), 'utf8');

// We will construct a test environment and run it
// Let's create an eval-like script that runs the checkAndTriggerGoogleSheetUpdates function with mocks
const testEnv = `
const db = {
  getSettings: () => ({
    googleScriptUrl: "https://script.google.com/macros/s/TEST_SCRIPT_ID/exec"
  })
};

// Mock fetchNoveltiesFromSheet to return test novelties
async function fetchNoveltiesFromSheet() {
  return [
    {
      interno: "145",
      rubro: "Herreria",
      subrubro: "Gancho",
      observacion: "ROMPIERON LAS TRABAS DE LA CAMA",
      mecanico: "",
      supervisor: ""
    },
    {
      interno: "111",
      rubro: "Gasoil",
      subrubro: "Perdida",
      observacion: "PERDIDA EN FILTRO",
      mecanico: "",
      supervisor: ""
    }
  ];
}

// Intercept fetch to verify the URL
let lastFetchUrl = null;
globalThis.fetch = async (url) => {
  lastFetchUrl = url;
  return {
    status: 200,
    text: async () => JSON.stringify({ status: "success", row: 2 })
  };
};

// Paste the function code from server.js
${serverCode.substring(
  serverCode.indexOf('async function checkAndTriggerGoogleSheetUpdates'),
  serverCode.indexOf('// Fallback: serve frontend index.html')
)}

// Run test case
async function runTest() {
  console.log("Running checkAndTriggerGoogleSheetUpdates test...");
  
  const existingOrder = {
    interno: "145",
    responsable: "Belocures, Cesar Hernán",
    tasks: [
      { id: "task1", descripcion: "Herreria - Gancho - ROMPIERON LAS TRABAS DE LA CAMA", status: "Pendiente" }
    ]
  };

  const updatedTasks = [
    { id: "task1", descripcion: "Herreria - Gancho - ROMPIERON LAS TRABAS DE LA CAMA", status: "Finalizada", empleado: "Cuba Orosco, Kevín Genaro" }
  ];

  await checkAndTriggerGoogleSheetUpdates(existingOrder, updatedTasks, "Belocures, Cesar Hernán", "145");

  console.log("Result URL:", lastFetchUrl);
  if (lastFetchUrl && lastFetchUrl.includes("mecanico=Cuba+Orosco%2C+Kev%C3%ADn+Genaro") && lastFetchUrl.includes("supervisor=Belocures%2C+Cesar+Hern%C3%A1n")) {
    console.log("TEST SUCCESS: Google Sheet update triggered with correct URL parameters!");
  } else {
    console.error("TEST FAILED: Incorrect or missing fetch URL.");
  }
}

runTest();
`;

fs.writeFileSync(path.join(__dirname, 'test_sheet_trigger_run.js'), testEnv, 'utf8');
console.log("Created test script.");
require('./test_sheet_trigger_run.js');
// Clean up
try { fs.unlinkSync(path.join(__dirname, 'test_sheet_trigger_run.js')); } catch(e){}
