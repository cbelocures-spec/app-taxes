const puppeteer = require('puppeteer');
const db = require('../database');
const fs = require('fs');

async function run() {
  const settings = db.getSettings();
  console.log("Launching browser...");
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 1000 });
    
    console.log(`Navigating to ${settings.portalUrl}/admin ...`);
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    
    console.log("Entering credentials...");
    const inputs = await page.$$('input');
    let usernameFilled = false;
    let passwordFilled = false;
    for (const input of inputs) {
      const type = await page.evaluate(el => el.type, input);
      if ((type === 'text' || type === 'email') && !usernameFilled) {
        await input.type(settings.username);
        usernameFilled = true;
      } else if (type === 'password' && !passwordFilled) {
        await input.type(settings.password);
        passwordFilled = true;
      }
    }
    
    await page.keyboard.press('Enter');
    await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
    await new Promise(r => setTimeout(r, 3000));
    
    console.log("Navigating to Flota...");
    await page.goto(`${settings.portalUrl}/tms/produccion/flota`, { waitUntil: 'networkidle2' });
    await new Promise(r => setTimeout(r, 3000));
    
    console.log("Dumping search inputs HTML...");
    const searchFormHTML = await page.evaluate(() => {
      const form = document.querySelector('form');
      if (!form) return "No form found";
      
      const inputsInfo = Array.from(form.querySelectorAll('input, select, button, a')).map(el => {
        return {
          tagName: el.tagName,
          type: el.getAttribute('type'),
          name: el.getAttribute('name'),
          id: el.getAttribute('id'),
          placeholder: el.getAttribute('placeholder'),
          value: el.value,
          outerHTML: el.outerHTML.substring(0, 200)
        };
      });
      return JSON.stringify(inputsInfo, null, 2);
    });
    
    console.log(searchFormHTML);
    
    // Check initial table rows
    const initialRows = await page.evaluate(() => {
      return document.querySelectorAll('table tbody tr').length;
    });
    console.log("Initial table row count:", initialRows);
    
    // Take initial screenshot
    await page.screenshot({ path: 'scratch/flota_initial.png' });
    
    // Try setting the limit and clicking search
    console.log("Trying to set limit 999 and click Buscar...");
    await page.evaluate(() => {
      const inputs = Array.from(document.querySelectorAll('input'));
      for (const inp of inputs) {
        const name = (inp.name || '').toLowerCase();
        if (name.includes('limit')) {
          inp.value = '999';
          inp.dispatchEvent(new Event('input', { bubbles: true }));
          inp.dispatchEvent(new Event('change', { bubbles: true }));
          console.log("Set limit to 999 on input:", inp.name);
        }
      }
      
      const buttons = Array.from(document.querySelectorAll('button, input[type="submit"]'));
      const buscar = buttons.find(b => b.textContent.includes('BUSCAR') || (b.value && b.value.includes('BUSCAR')));
      if (buscar) {
        buscar.click();
        console.log("Clicked search button");
      }
    });
    
    console.log("Waiting for search results...");
    await new Promise(r => setTimeout(r, 6000));
    
    // Check new table rows
    const afterRows = await page.evaluate(() => {
      return document.querySelectorAll('table tbody tr').length;
    });
    console.log("Table row count after search:", afterRows);
    
    // Take final screenshot
    await page.screenshot({ path: 'scratch/flota_after_search.png' });
    
  } catch (err) {
    console.error("Error:", err);
  } finally {
    await browser.close();
    console.log("Done.");
  }
}

run();
