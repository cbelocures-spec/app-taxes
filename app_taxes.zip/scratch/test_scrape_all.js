const puppeteer = require('puppeteer');
const db = require('../database');

async function run() {
  const settings = db.getSettings();
  console.log("Launching browser...");
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 1000 });
    
    console.log("Logging in...");
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const inputs = await page.$$('input');
    let u = false, p = false;
    for (const input of inputs) {
      const type = await page.evaluate(el => el.type, input);
      if ((type === 'text' || type === 'email') && !u) { await input.type(settings.username); u = true; }
      else if (type === 'password' && !p) { await input.type(settings.password); p = true; }
    }
    await page.keyboard.press('Enter');
    await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
    await new Promise(r => setTimeout(r, 3000));
    
    console.log("Navigating to Flota...");
    await page.goto(`${settings.portalUrl}/tms/produccion/flota`, { waitUntil: 'networkidle2' });
    await new Promise(r => setTimeout(r, 3000));
    
    // Set limit input to 999
    console.log("Setting limit input to 999...");
    await page.evaluate(() => {
      const limitInput = document.getElementById('limite');
      if (limitInput) {
        limitInput.value = '999';
        limitInput.dispatchEvent(new Event('input', { bubbles: true }));
        limitInput.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
    
    console.log("Clicking BUSCAR...");
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button, input[type="submit"]'));
      const buscar = buttons.find(b => b.textContent.includes('BUSCAR'));
      if (buscar) buscar.click();
    });
    
    console.log("Waiting for search results...");
    await new Promise(r => setTimeout(r, 6000));
    
    let allVehicles = [];
    let hasNextPage = true;
    let pageNum = 1;
    
    while (hasNextPage) {
      console.log(`Scraping DataTable page ${pageNum}...`);
      
      const pageVehicles = await page.evaluate(() => {
        const results = [];
        const mainTable = document.querySelector('#tabla_flota');
        if (!mainTable) return results;
        
        const rows = mainTable.querySelectorAll('tbody tr');
        for (const row of rows) {
          const cells = row.querySelectorAll('td');
          if (cells.length < 3) continue;
          
          const cellTexts = Array.from(cells).map(c => c.textContent.trim());
          const interno = cellTexts[1] || '';
          const modelo = cellTexts[2] || '';
          const patente = cellTexts[3] || '';
          
          if (!modelo || modelo === '-' || modelo === 'Ningún dato disponible en esta tabla') continue;
          
          let label = modelo;
          if (interno && !label.toLowerCase().includes('interno')) {
            label += ` Interno ${interno}`;
          }
          
          // Get vehicle ID
          let value = '';
          const link = row.querySelector('a');
          if (link) {
            const href = link.href || '';
            const idMatch = href.match(/\/(\d+)(?:\/|$|\?)/);
            if (idMatch) value = idMatch[1];
          }
          if (!value && interno) value = interno;
          
          results.push({ value, label, interno, modelo, patente });
        }
        return results;
      });
      
      console.log(`Found ${pageVehicles.length} vehicles on DataTable page ${pageNum}.`);
      allVehicles.push(...pageVehicles);
      
      // Check if "Siguiente" button is enabled
      const nextButtonInfo = await page.evaluate(() => {
        // The Siguiente button is usually in the pagination div
        const nextBtn = document.querySelector('#tabla_flota_next');
        if (!nextBtn) return { exists: false };
        
        const isDisabled = nextBtn.classList.contains('disabled') || 
                           nextBtn.getAttribute('aria-disabled') === 'true' ||
                           nextBtn.classList.contains('ui-state-disabled');
        return { exists: true, disabled: isDisabled };
      });
      
      if (nextButtonInfo.exists && !nextButtonInfo.disabled) {
        console.log("Clicking 'Siguiente'...");
        await page.click('#tabla_flota_next');
        await new Promise(r => setTimeout(r, 1500)); // wait for DataTable page transition
        pageNum++;
      } else {
        console.log("No more pages in DataTable.");
        hasNextPage = false;
      }
    }
    
    console.log(`Total vehicles scraped: ${allVehicles.length}`);
    console.log("First 5 vehicles:", allVehicles.slice(0, 5));
    console.log("Last 5 vehicles:", allVehicles.slice(-5));
    
  } catch (err) {
    console.error(err);
  } finally {
    await browser.close();
  }
}

run();
