const fs = require('fs');
const readline = require('readline');

const logPath = 'C:\\Users\\admin\\.gemini\\antigravity\\brain\\d03ca953-b01d-40e0-af0b-75db698ee58a\\.system_generated\\logs\\transcript.jsonl';

async function printLines() {
  const fileStream = fs.createReadStream(logPath);
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });

  let lineNum = 0;
  for await (const line of rl) {
    lineNum++;
    try {
      const data = JSON.parse(line);
      if (data.step_index >= 2910 && data.step_index <= 2980) {
        console.log(`[Line ${lineNum}] Step ${data.step_index} (${data.source} - ${data.type}):`);
        console.log((data.content || '').substring(0, 500));
        if (data.thinking) console.log(`THINKING: ${data.thinking.substring(0, 500)}`);
        console.log('='.repeat(50));
      }
    } catch (e) {}
  }
}

printLines();
