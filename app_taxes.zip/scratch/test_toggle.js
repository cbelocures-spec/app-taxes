const db = require('../database');

console.log("Creating test work order with Finalizada task...");
const order = db.createWorkOrder({
  rodado: "VOLKSWAGEN - SAVEIRO 1.6L Interno 2",
  responsable: "AUTO",
  fechaEntrega: "2026-06-04",
  horario: "12:30",
  interno: "int 2 test toggle",
  clasificacion: "Correctivo",
  incidente: "Test toggle task switch status",
  tasks: [
    {
      centroCosto: "15", // MECANICA
      empleado: "394", // Acosta Riveros, Claudia
      horasEstimadas: 1.5,
      descripcion: "Test task marked as Finalizada",
      status: "Finalizada"
    }
  ]
});

console.log("Created order ID:", order.id, "Status:", order.syncStatus);
console.log("The background sync worker should pick it up automatically in a few seconds.");
