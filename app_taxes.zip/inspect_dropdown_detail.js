const puppeteer = require('puppeteer');
const db = require('./database');

async function inspectDropdownDetail() {
  const settings = db.getSettings();
  console.log("Using credentials:", settings.username);
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // Login
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Inicio') || document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if (type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) {
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }

    // Go to OT list and click NUEVO
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2' });
    await new Promise(res => setTimeout(res, 3000));
    
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const nuevo = buttons.find(b => b.textContent.trim().toUpperCase().includes('NUEVO'));
      if (nuevo) nuevo.click();
    });
    await new Promise(res => setTimeout(res, 3000));

    // Find Rodado searchable input
    const inputSelector = await page.evaluate(() => {
      const groups = Array.from(document.querySelectorAll('.form-group, .taxes-form-group'));
      const rodadoGroup = groups.find(g => g.textContent.toLowerCase().includes('rodado'));
      if (rodadoGroup) {
        const input = rodadoGroup.querySelector('.searchable-input, input[type="text"]');
        if (input) {
          input.setAttribute('id', 'test_rodado_input');
          return '#test_rodado_input';
        }
      }
      return null;
    });

    if (inputSelector) {
      // 1. Log dropdown state BEFORE clicking
      const beforeClick = await page.evaluate(() => {
        const dropdowns = Array.from(document.querySelectorAll('[id^="searchable-select-dropdown-"]'));
        return dropdowns.map(d => ({
          id: d.id,
          className: d.className,
          offsetWidth: d.offsetWidth,
          offsetHeight: d.offsetHeight,
          display: window.getComputedStyle(d).display,
          visibility: window.getComputedStyle(d).visibility,
          opacity: window.getComputedStyle(d).opacity,
          html: d.innerHTML.substring(0, 200)
        }));
      });
      console.log("\n=== DROPDOWN STATE BEFORE CLICK ===");
      console.log(JSON.stringify(beforeClick, null, 2));

      // 2. Click input
      console.log("\nClicking Rodado input...");
      await page.click(inputSelector);
      await new Promise(res => setTimeout(res, 1000));

      // 3. Log dropdown state AFTER clicking
      const afterClick = await page.evaluate(() => {
        const dropdowns = Array.from(document.querySelectorAll('[id^="searchable-select-dropdown-"]'));
        return dropdowns.map(d => ({
          id: d.id,
          className: d.className,
          offsetWidth: d.offsetWidth,
          offsetHeight: d.offsetHeight,
          display: window.getComputedStyle(d).display,
          visibility: window.getComputedStyle(d).visibility,
          opacity: window.getComputedStyle(d).opacity,
          html: d.innerHTML.substring(0, 200)
        }));
      });
      console.log("\n=== DROPDOWN STATE AFTER CLICK ===");
      console.log(JSON.stringify(afterClick, null, 2));

      // 4. Type "FORD"
      console.log("\nTyping 'FORD'...");
      await page.type(inputSelector, "FORD", { delay: 100 });
      await new Promise(res => setTimeout(res, 2000));

      // 5. Log dropdown state AFTER typing
      const afterType = await page.evaluate(() => {
        const dropdowns = Array.from(document.querySelectorAll('[id^="searchable-select-dropdown-"]'));
        return dropdowns.map(d => ({
          id: d.id,
          className: d.className,
          offsetWidth: d.offsetWidth,
          offsetHeight: d.offsetHeight,
          display: window.getComputedStyle(d).display,
          visibility: window.getComputedStyle(d).visibility,
          opacity: window.getComputedStyle(d).opacity,
          optionsCount: d.querySelectorAll('div').length,
          optionsText: Array.from(d.querySelectorAll('div')).map(el => el.textContent.trim()).filter(t => t.length > 0).slice(0, 10)
        }));
      });
      console.log("\n=== DROPDOWN STATE AFTER TYPING ===");
      console.log(JSON.stringify(afterType, null, 2));

    } else {
      console.log("Rodado input not found!");
    }

  } catch (error) {
    console.error("Error:", error);
  } finally {
    await browser.close();
  }
}

inspectDropdownDetail();
