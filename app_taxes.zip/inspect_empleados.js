const puppeteer = require('puppeteer');
const db = require('./database');

async function testScrapeCatalogs() {
  const settings = db.getSettings();
  console.log("=== TEST SCRAPE CATALOGS ===");
  console.log("Usuario:", settings.username);
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1400, height: 1000 });

    // Login
    await page.goto(`${settings.portalUrl}/admin`, { waitUntil: 'networkidle2' });
    const isLoggedIn = await page.evaluate(() => {
      return document.body.textContent.includes('Inicio') || document.querySelector('.profile-user') !== null;
    });

    if (!isLoggedIn) {
      const inputs = await page.$$('input');
      for (const input of inputs) {
        const type = await page.evaluate(el => el.type, input);
        const name = await page.evaluate(el => el.name || '', input);
        if (type === 'text' || type === 'email' || name.includes('email') || name.includes('user')) {
          await input.type(settings.username);
        } else if (type === 'password' || name.includes('pass')) {
          await input.type(settings.password);
        }
      }
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
      await new Promise(res => setTimeout(res, 3000));
    }
    console.log("Login OK");

    // Go to OT list page
    await page.goto(`${settings.portalUrl}/tms/produccion/ot`, { waitUntil: 'networkidle2' });
    
    console.log("Waiting for selects to load...");
    await page.waitForSelector('select', { timeout: 10000 });
    
    console.log("Waiting for employee select options to populate...");
    await page.waitForFunction(() => {
      const selects = Array.from(document.querySelectorAll('select'));
      return selects.some(s => s.options.length > 50);
    }, { timeout: 15000 }).catch(e => console.log("Timeout waiting for employee select options: " + e.message));

    // 1. Scrape all employees from the select that has the most options
    console.log("Scraping employees/responsibles from list page...");
    const selectSummary = await page.evaluate(() => {
      const selects = Array.from(document.querySelectorAll('select'));
      return selects.map((s, i) => ({
        index: i,
        id: s.id,
        className: s.className,
        optionCount: s.options.length,
        firstOption: s.options.length > 0 ? s.options[0].textContent.trim() : '(none)'
      }));
    });
    console.log("Selects on list page:", JSON.stringify(selectSummary, null, 2));

    const employees = await page.evaluate(() => {
      const selects = Array.from(document.querySelectorAll('select'));
      let empSelect = null;
      let maxOptions = 0;
      for (const s of selects) {
        if (s.options.length > maxOptions) {
          maxOptions = s.options.length;
          empSelect = s;
        }
      }

      if (empSelect && maxOptions > 50) {
        return Array.from(empSelect.options)
          .filter(opt => opt.value && opt.value !== '0' && opt.value !== '')
          .map(opt => ({
            value: opt.value,
            label: opt.textContent.trim()
          }));
      }
      return [];
    });

    console.log(`Found ${employees.length} employees/responsibles.`);
    if (employees.length > 0) {
      console.log("Sample:", JSON.stringify(employees.slice(0, 5), null, 2));
    }

    // 2. Click NUEVO
    console.log("Opening NUEVO form...");
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button, a'));
      const nuevo = buttons.find(b => b.textContent.trim().toUpperCase().includes('NUEVO'));
      if (nuevo) nuevo.click();
    });
    
    // Wait for the modal / creation form to open
    console.log("Waiting for modal to open...");
    await page.waitForSelector('select[name="inv_ot_clasificacion_id"]', { timeout: 10000 });

    // 3. Click AGREGAR TAREA
    console.log("Clicking AGREGAR TAREA...");
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const addBtn = buttons.find(b => b.textContent.includes('AGREGAR TAREA') || b.textContent.includes('Agregar Tarea'));
      if (addBtn) addBtn.click();
    });
    
    // Wait for task card to appear
    console.log("Waiting for task card to appear...");
    await page.waitForSelector('select[name="syj_centro_costo_id_0"]', { timeout: 10000 });

    console.log("Waiting for Centro de Costo options to populate...");
    await page.waitForFunction(() => {
      const ccSelect = document.querySelector('select[name="syj_centro_costo_id_0"]');
      return ccSelect && ccSelect.options.length > 1;
    }, { timeout: 10000 }).catch(e => console.log("Timeout waiting for CC options: " + e.message));

    // 4. Scrape Centros de Costo from the newly added task card
    console.log("Scraping Centros de Costo from task card...");
    const centrosCosto = await page.evaluate(() => {
      const ccSelect = document.querySelector('select[name="syj_centro_costo_id_0"]');
      if (ccSelect) {
        return Array.from(ccSelect.options)
          .filter(opt => opt.value && opt.value !== '')
          .map(opt => ({
            value: opt.value,
            label: opt.textContent.trim()
          }));
      }
      return [];
    });

    console.log(`Found ${centrosCosto.length} Centros de Costo.`);
    console.log("Options:", JSON.stringify(centrosCosto, null, 2));

  } catch (error) {
    console.error("Error:", error);
  } finally {
    await browser.close();
  }
}

testScrapeCatalogs();
